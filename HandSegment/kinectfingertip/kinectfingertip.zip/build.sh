g++ -I/usr/include/ni -lOpenNI `pkg-config --libs opencv` -o KinectFingertip *.cpp
