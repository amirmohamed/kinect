./KinectFingertip
